function doCaesarCipher(str) {
    var solved = "";
    for (let i = 0; i < str.length; i++) {
        let asciiNum = str[i].charCodeAt();
        if (asciiNum >= 65 && asciiNum <= 77) {
            solved += String.fromCharCode(asciiNum + 13);
        } else if (asciiNum >= 78 && asciiNum <= 90) {
            solved += String.fromCharCode(asciiNum - 13);
        } else {
            solved += str[i];
        }
    }
    return solved;
}

function doEmilyQrpao(str) {
    let result = "";
    for (let i = 0; i < str.length; i++) {
        switch (str[i]) {
            case 'E':
                result = result.concat('Q');
                continue;
            case 'M':
                result = result.concat('R');
                continue;
            case 'I':
                result = result.concat('P');
                continue;
            case 'L':
                result = result.concat('A');
                continue;
            case 'Y':
                result = result.concat('O');
                continue;
            case 'Q':
                result = result.concat('E');
                continue;
            case 'R':
                result = result.concat('M');
                continue;
            case 'P':
                result = result.concat('I');
                continue;
            case 'A':
                result = result.concat('L');
                continue;
            case 'O':
                result = result.concat('Y');
                continue;
            default:
                result = result.concat(str[i]);
                continue;
        }
    }
    return result;
}

function doZenitPolar(str) {
    let result = "";
    for (let i = 0; i < str.length; i++) {
        switch (str[i]) {
            case 'Z':
                result = result.concat('P');
                continue;
            case 'E':
                result = result.concat('O');
                continue;
            case 'N':
                result = result.concat('L');
                continue;
            case 'I':
                result = result.concat('A');
                continue;
            case 'T':
                result = result.concat('R');
                continue;
            case 'P':
                result = result.concat('Z');
                continue;
            case 'O':
                result = result.concat('E');
                continue;
            case 'L':
                result = result.concat('N');
                continue;
            case 'A':
                result = result.concat('I');
                continue;
            case 'R':
                result = result.concat('T');
                continue;
            default:
                result = result.concat(str[i]);
                continue;
        }
    }
    return result;
}

function encryptData(str) {
    let result = doCaesarCipher(doZenitPolar(doEmilyQrpao(str)));
    return result;
}

function decryptData(str) {
    let result = doEmilyQrpao(doZenitPolar(doCaesarCipher(str)));
    return result;
}

function init(str) {
    let encrypted = encryptData(str);
    let decrypted = decryptData(encrypted);
}